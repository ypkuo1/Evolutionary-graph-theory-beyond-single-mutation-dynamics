st = shortcut graph
de = detour graph
reg = regular graph